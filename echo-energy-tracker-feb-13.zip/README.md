1. CMD run pip install
2. CMD run main.py
